public class Ingredient {

    String name;
    float quantite;

    Ingredient(String p_name, float p_quantite)
    {
        this.name = p_name;
        this.quantite = p_quantite;
    }
}
